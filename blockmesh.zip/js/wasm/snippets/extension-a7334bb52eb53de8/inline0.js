
    export async function clear_badge() {
        try {
            await chrome.action.setBadgeText({ text: '' });
        } catch (e) {
            console.log('clear_badge', { e })
        }
    }