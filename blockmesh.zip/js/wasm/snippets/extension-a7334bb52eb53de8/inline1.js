
    export function open_new_tab(url) {
        function onSuccess(message) {
            console.log(`open_new_tab::onSuccess: ${JSON.stringify(message)}`);
        }
        function onError(error) {
            console.log(`open_new_tab::onError: ${error}`);
        }
        try {
            if (chrome?.wootz) {
                chrome.runtime.sendMessage({action: "open_new_tab", url: url}).then(onSuccess, onError)
            } else {
                window.open(url,'_blank');
            }
        } catch (e) {
            console.log('open_new_tab', { e })
        }
    }